window.calculator = new CalcController();

